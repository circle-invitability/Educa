https://www.food.com/



<nav>
    <ul>
      <div class="head-title">
        <li><a href="#" class="head-receipes">RECEIPES</a></li>
        <div class="dropdown-content-receipes">
          <a href="receipt-1" class="dropdown-link"> Breakfast and Brunch Receipts</a>
          <a href="receipt-2" class="dropdown-link">Lunch Receipts</a>
          <a href="receipt-3" class="dropdown-link">Appetizers and Snack receipts</a>
          <a href="receipt-4" class="dropdown-link">Dinner Recipes</a>
          <a href="receipt-5" class="dropdown-link">Desert Recipes</a>
          <a href="receipt-6" class="dropdown-link">Drinks and Cocktail Resceipes</a>
          <a href="receipt-7" class="dropdown-link">Side Dish recepts</a>
          <a href="receipt-8" class="dropdown-link">Grilling and BBQ Receipes</a>
          <a href="receipt-9" class="dropdown-link">Microwave Recipes</a>
          <a href="receipt-10" class="dropdown-link">Quick and Easy Receipes</a>
          <a href="receipt-11" class="dropdown-link">Slow-Cooker Recipes</a>
          <a href="receipt-12" class="dropdown-link">Air Fryer Recipes</a>
          <a href="receipt-13" class="dropdown-link">Instant Pot Recipes</a>
          <a href="receipt-14" class="dropdown-link">Baking Recipes</a>
          <a href="see-more" class="dropdown-link see-more">SEE MORE</a>
        </div>
      </div>

      <div class="dropdown-popular">
        <li><a href="#" class="head-title">POPULAR</a></li>
        <div class="dropdown-content-popular">
          <a href="popular-1" class="dropdown-link">Trending Now</a>
          <a href="popular-2" class="dropdown-link">Cassarole Receipes</a>
          <a href="popular-3" class="dropdown-link">Chilli Receipes</a>
          <a href="popular-3" class="dropdown-link">Soup Recipes</a>
          <a href="popular-3" class="dropdown-link">Pasta Recipes</a>
          <a href="popular-3" class="dropdown-link">Bread Recipes</a>
          <a href="popular-3" class="dropdown-link">Cookie Recipes</a>
          <a href="popular-3" class="dropdown-link">Salad Recipes</a>
          <a href="popular-3" class="dropdown-link">Tofu Recipes</a>
          <a href="popular-3" class="dropdown-link">Copycat Recipes</a>
          <a href="see-more" class="dropdown-link see-more">See More</a>
        </div>
      </div>




</div>


<li><a href="#" >MEAT & SEAFOOD</a></li>
<li><a href="#">HEALTHY & DIET</a></li>
<li><a href="#">HOLIDAYS</a></li>
<li><a href="#">CUISINE</a></li>
<li><a href="#">SEASONAL</a></li>
</ul>
</nav>